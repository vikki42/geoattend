import React, { useState, useEffect } from 'react';
import { MapPin, Clock, History, User, CheckCircle2, LogOut, Loader2, AlertCircle, Settings, X, Save, Mail, Lock, Key, Moon, Sun, Users, DollarSign, FileText, Download, ShieldCheck, Map as MapIcon, Trash2, Calendar, Megaphone, Receipt, Plus, Briefcase, ChevronRight, Info, Navigation } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';

// Fix for default marker icon issue in Leaflet + React
// @ts-ignore
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const officeIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

interface AttendanceRecord {
  id: number;
  user_name: string;
  type: 'check-in' | 'check-out';
  latitude: number;
  longitude: number;
  status: 'on-time' | 'late' | 'regularized';
  regularization_reason?: string;
  timestamp: string;
}

interface SettingsData {
  office_lat: string;
  office_lng: string;
  allowed_radius: string;
}

interface UserData {
  id: number;
  username: string;
  email: string;
  role: 'ceo' | 'hr' | 'employee';
}

interface Employee {
  id: number;
  username: string;
  email: string;
  role: 'ceo' | 'hr' | 'employee';
  base_salary: number;
  esi_enabled: boolean;
  pf_enabled: boolean;
  joining_date: string;
}

interface LiveLocation {
  user_id: number;
  username: string;
  latitude: number;
  longitude: number;
  last_updated: string;
}

interface LeaveRequest {
  id: number;
  user_id: number;
  username: string;
  type: 'sick' | 'casual' | 'earned' | 'unpaid';
  start_date: string;
  end_date: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

interface Announcement {
  id: number;
  title: string;
  content: string;
  author_id: number;
  author_name: string;
  created_at: string;
}

interface ExpenseClaim {
  id: number;
  user_id: number;
  username: string;
  amount: number;
  category: string;
  description: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

// Map re-centering component
function MapRecenter({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    if (center[0] && center[1]) {
      map.setView(center, map.getZoom());
    }
  }, [center, map]);
  return null;
}

export default function App() {
  const [user, setUser] = useState<UserData | null>(null);
  const [isRegistering, setIsRegistering] = useState(false);
  const [authForm, setAuthForm] = useState({ identifier: '', email: '', username: '', password: '' });
  
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<'idle' | 'success'>('idle');
  const [showSettings, setShowSettings] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [profileForm, setProfileForm] = useState({ username: '', email: '', password: '', currentPassword: '' });
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardingForm, setOnboardingForm] = useState({ 
    username: '', 
    email: '', 
    password: '', 
    role: 'employee', 
    base_salary: '0',
    esi_enabled: false,
    pf_enabled: false,
    joining_date: new Date().toISOString().split('T')[0],
    shift_id: '1'
  });
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [liveLocations, setLiveLocations] = useState<LiveLocation[]>([]);
  const [payroll, setPayroll] = useState<any>(null);
  const [selectedEmployeeHistory, setSelectedEmployeeHistory] = useState<Employee | null>(null);
  const [employeeHistoryRecords, setEmployeeHistoryRecords] = useState<AttendanceRecord[]>([]);
  const [locationVerified, setLocationVerified] = useState<boolean | null>(null);
  const [distanceFromOffice, setDistanceFromOffice] = useState<number | null>(null);
  const [historyMapCenter, setHistoryMapCenter] = useState<[number, number] | null>(null);
  
  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [expenses, setExpenses] = useState<ExpenseClaim[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [shifts, setShifts] = useState<any[]>([]);
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [showAnnouncementModal, setShowAnnouncementModal] = useState(false);
  
  const [leaveForm, setLeaveForm] = useState({ type: 'sick', start_date: '', end_date: '', reason: '' });
  const [expenseForm, setExpenseForm] = useState({ amount: '', category: 'travel', description: '' });
  const [announcementForm, setAnnouncementForm] = useState({ title: '', content: '' });
  
  const [activeTab, setActiveTab] = useState<'attendance' | 'hr' | 'payroll' | 'leaves' | 'announcements' | 'expenses' | 'config'>('attendance');
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') === 'dark' || 
        (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
    return false;
  });
  
  const [settings, setSettings] = useState<SettingsData>({
    office_lat: '12.9716',
    office_lng: '77.5946',
    allowed_radius: '300'
  });

  useEffect(() => {
    const checkHealth = async () => {
      try {
        const res = await fetch('/api/health');
        if (res.ok) {
          console.log('Server is healthy');
          fetchSettings();
          fetchLocations();
          fetchShifts();
        }
      } catch (err) {
        console.warn('Server not ready, retrying health check...');
        setTimeout(checkHealth, 2000);
      }
    };
    checkHealth();
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  // Live location tracking for the current user
  useEffect(() => {
    if (!user) return;

    const updateLiveLocation = () => {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          try {
            await fetch('/api/live-location', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                userId: user.id,
                latitude: pos.coords.latitude,
                longitude: pos.coords.longitude
              }),
            });
          } catch (err) {
            console.error('Failed to update live location', err);
          }
        },
        (err) => console.error('Geolocation error', err),
        { enableHighAccuracy: true }
      );
    };

    // Update immediately and then every 30 seconds
    updateLiveLocation();
    const interval = setInterval(updateLiveLocation, 30000);
    return () => clearInterval(interval);
  }, [user]);

  // Fetch all live locations for Admin/HR
  useEffect(() => {
    if (!user || user.role === 'employee') return;

    const fetchLiveLocations = async () => {
      try {
        const response = await fetch('/api/live-locations');
        if (response.ok) {
          const data = await response.json();
          setLiveLocations(data);
        }
      } catch (err) {
        console.error('Failed to fetch live locations', err);
      }
    };

    fetchLiveLocations();
    const interval = setInterval(fetchLiveLocations, 15000);
    return () => clearInterval(interval);
  }, [user]);

  useEffect(() => {
    if (user) {
      fetchRecords(user.role === 'employee' ? user.id : undefined);
      fetchAnnouncements();
      if (user.role !== 'employee') {
        fetchEmployees();
      }
    }
  }, [user]);

  useEffect(() => {
    if (!user) return;
    if (activeTab === 'attendance' && locationVerified === null) {
      verifyLocation();
    }
    if (activeTab === 'leaves') fetchLeaves(user.role === 'employee' ? user.id : undefined);
    if (activeTab === 'expenses') fetchExpenses(user.role === 'employee' ? user.id : undefined);
    if (activeTab === 'announcements') fetchAnnouncements();
  }, [activeTab, user]);

  // Geofencing logic
  useEffect(() => {
    if (!user) return;

    const interval = setInterval(async () => {
      try {
        const pos = await getLocation();
        
        // Check if user is within radius of ANY configured location
        let isInside = false;
        if (locations.length > 0) {
          locations.forEach(loc => {
            const dist = calculateDistance(pos.lat, pos.lng, loc.latitude, loc.longitude);
            if (dist <= loc.radius) isInside = true;
          });
        } else {
          const dist = calculateDistance(pos.lat, pos.lng, parseFloat(settings.office_lat), parseFloat(settings.office_lng));
          isInside = dist <= parseFloat(settings.allowed_radius);
        }

        const lastRecord = records[0];

        if (isInside && (!lastRecord || lastRecord.type === 'check-out')) {
          console.log('Auto check-in triggered');
          handleAttendance('check-in', pos);
        } else if (!isInside && lastRecord?.type === 'check-in') {
          console.log('Auto check-out triggered');
          handleAttendance('check-out', pos);
        }
      } catch (err) {
        console.error('Geofencing error', err);
      }
    }, 60000); // Check every minute

    return () => clearInterval(interval);
  }, [user, settings, records, locations]);

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/settings');
      if (!response.ok) {
        throw new Error(`Server responded with ${response.status}`);
      }
      const data = await response.json();
      if (data.office_lat) setSettings(data);
    } catch (err: any) {
      console.error('Failed to fetch settings:', err.message);
      // If it's a network error, maybe the server is still starting
      if (err.message === 'Failed to fetch') {
        setTimeout(fetchSettings, 2000);
      }
    }
  };

  const fetchLocations = async () => {
    try {
      const response = await fetch('/api/locations');
      if (!response.ok) throw new Error(`Server responded with ${response.status}`);
      const data = await response.json();
      setLocations(data);
    } catch (err: any) {
      console.error('Failed to fetch locations:', err.message);
      if (err.message === 'Failed to fetch') {
        setTimeout(fetchLocations, 2000);
      }
    }
  };

  const fetchShifts = async () => {
    try {
      const response = await fetch('/api/shifts');
      if (!response.ok) throw new Error(`Server responded with ${response.status}`);
      const data = await response.json();
      setShifts(data);
    } catch (err: any) {
      console.error('Failed to fetch shifts:', err.message);
      if (err.message === 'Failed to fetch') {
        setTimeout(fetchShifts, 2000);
      }
    }
  };

  const saveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch('/api/settings', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'x-user-role': user?.role || ''
        },
        body: JSON.stringify(settings),
      });
      if (response.ok) {
        setShowSettings(false);
        setStatus('success');
        setTimeout(() => setStatus('idle'), 2000);
      }
    } catch (err) {
      console.error('Failed to save settings', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteLocation = async (id: number) => {
    if (!confirm('Are you sure you want to delete this location?')) return;
    try {
      const response = await fetch(`/api/locations/${id}`, {
        method: 'DELETE',
        headers: { 'x-user-role': user?.role || '' }
      });
      if (response.ok) {
        fetchLocations();
      } else {
        const err = await response.json();
        alert(`Failed to delete location: ${err.error}`);
      }
    } catch (err) {
      console.error('Failed to delete location', err);
    }
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // Earth radius in meters
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // Distance in meters
  };

  const fetchRecords = async (userId?: number, isMainView = true) => {
    try {
      const url = userId ? `/api/attendance?userId=${userId}` : '/api/attendance';
      const response = await fetch(url);
      const data = await response.json();
      if (Array.isArray(data)) {
        if (isMainView) {
          setRecords(data);
        } else {
          setEmployeeHistoryRecords(data);
        }
      } else {
        console.error('Expected array of records, got:', data);
        if (isMainView) setRecords([]);
        else setEmployeeHistoryRecords([]);
      }
    } catch (err) {
      console.error('Failed to fetch records', err);
      if (isMainView) setRecords([]);
      else setEmployeeHistoryRecords([]);
    }
  };

  const fetchEmployees = async () => {
    try {
      const response = await fetch('/api/employees', {
        headers: { 'x-user-role': user?.role || '' }
      });
      const data = await response.json();
      setEmployees(data);
    } catch (err) {
      console.error('Failed to fetch employees', err);
    }
  };

  const fetchLeaves = async (userId?: number) => {
    try {
      const url = userId ? `/api/leaves?userId=${userId}` : '/api/leaves';
      const response = await fetch(url);
      const data = await response.json();
      setLeaves(data);
    } catch (err) {
      console.error('Failed to fetch leaves', err);
    }
  };

  const fetchAnnouncements = async () => {
    try {
      const response = await fetch('/api/announcements');
      const data = await response.json();
      setAnnouncements(data);
    } catch (err) {
      console.error('Failed to fetch announcements', err);
    }
  };

  const fetchExpenses = async (userId?: number) => {
    try {
      const url = userId ? `/api/expenses?userId=${userId}` : '/api/expenses';
      const response = await fetch(url);
      const data = await response.json();
      setExpenses(data);
    } catch (err) {
      console.error('Failed to fetch expenses', err);
    }
  };

  const fetchPayroll = async (userId: number) => {
    try {
      const response = await fetch(`/api/payroll/${userId}`);
      const data = await response.json();
      setPayroll(data);
    } catch (err) {
      console.error('Failed to fetch payroll', err);
    }
  };

  const handleRegularize = async (attendanceId: number, reason: string) => {
    try {
      const response = await fetch('/api/regularize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ attendanceId, reason }),
      });
      if (response.ok) {
        fetchRecords(user.role === 'employee' ? user.id : undefined);
      }
    } catch (err) {
      console.error('Failed to regularize', err);
    }
  };

  const exportAttendance = () => {
    window.open('/api/export/attendance', '_blank');
  };

  const getLocation = (): Promise<{ lat: number; lng: number }> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation not supported'));
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        (err) => reject(err),
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    });
  };

  const handleDeleteEmployee = async (employeeId: number) => {
    if (!confirm('Are you sure you want to delete this employee? This action cannot be undone.')) return;
    
    try {
      const response = await fetch(`/api/employees/${employeeId}`, {
        method: 'DELETE',
        headers: { 'x-user-role': user?.role || '' }
      });
      if (response.ok) {
        fetchEmployees();
      } else {
        const data = await response.json();
        alert(data.error || 'Failed to delete employee');
      }
    } catch (err) {
      console.error('Delete failed', err);
    }
  };

  const verifyLocation = async () => {
    setLoading(true);
    setError(null);
    try {
      const loc = await getLocation();
      setLocation(loc);
      
      let isInside = false;
      let minDistance = Infinity;
      let nearestOffice = '';

      if (locations.length > 0) {
        locations.forEach(l => {
          const d = calculateDistance(loc.lat, loc.lng, l.latitude, l.longitude);
          if (d <= l.radius) isInside = true;
          if (d < minDistance) {
            minDistance = d;
            nearestOffice = l.name;
          }
        });
      } else {
        const d = calculateDistance(loc.lat, loc.lng, parseFloat(settings.office_lat), parseFloat(settings.office_lng));
        isInside = d <= parseFloat(settings.allowed_radius);
        minDistance = d;
        nearestOffice = 'Main Office';
      }

      setDistanceFromOffice(minDistance);
      setLocationVerified(isInside);
      if (!isInside) {
        setError(`You are ${Math.round(minDistance)}m away from ${nearestOffice}. (Your location: ${loc.lat.toFixed(6)}, ${loc.lng.toFixed(6)}). Please move closer or update the office coordinates in the Config tab.`);
      } else {
        setStatus('idle');
        // Center map on the nearest office if verified
        const nearest = locations.find(l => l.name === nearestOffice) || { latitude: parseFloat(settings.office_lat), longitude: parseFloat(settings.office_lng) };
        setLocation({ lat: nearest.latitude, lng: nearest.longitude });
      }
    } catch (err: any) {
      setError(err.message || "Failed to get location. Please enable GPS.");
      setLocationVerified(false);
    } finally {
      setLoading(false);
    }
  };

  const handleAttendance = async (type: 'check-in' | 'check-out', forcedLocation?: { lat: number; lng: number }) => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const loc = forcedLocation || await getLocation();
      setLocation(loc);

      let isInside = false;
      let minDistance = Infinity;
      let nearestOffice = '';

      if (locations.length > 0) {
        locations.forEach(l => {
          const d = calculateDistance(loc.lat, loc.lng, l.latitude, l.longitude);
          if (d <= l.radius) isInside = true;
          if (d < minDistance) {
            minDistance = d;
            nearestOffice = l.name;
          }
        });
      } else {
        const d = calculateDistance(loc.lat, loc.lng, parseFloat(settings.office_lat), parseFloat(settings.office_lng));
        isInside = d <= parseFloat(settings.allowed_radius);
        minDistance = d;
        nearestOffice = 'Main Office';
      }

      if (!isInside) {
        throw new Error(`You are too far from ${nearestOffice} (${Math.round(minDistance)}m away). Your location: ${loc.lat.toFixed(6)}, ${loc.lng.toFixed(6)}`);
      }

      const response = await fetch('/api/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          type,
          latitude: loc.lat,
          longitude: loc.lng,
        }),
      });

      if (!response.ok) throw new Error('Failed to record attendance');

      setStatus('success');
      setTimeout(() => setStatus('idle'), 3000);
      fetchRecords(user.role === 'employee' ? user.id : undefined);
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const endpoint = isRegistering ? '/api/register' : '/api/login';
      const body = isRegistering 
        ? { username: authForm.username, email: authForm.email, password: authForm.password }
        : { identifier: authForm.identifier, password: authForm.password };

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Authentication failed');

      if (isRegistering) {
        setIsRegistering(false);
        setStatus('success');
        setError('Account created! Please login.');
        setAuthForm(prev => ({ ...prev, identifier: prev.username }));
      } else {
        setUser(data);
        setProfileForm({ username: data.username, email: data.email, password: '', currentPassword: '' });
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleOnboarding = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch('/api/employees', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'x-user-role': user?.role || ''
        },
        body: JSON.stringify(onboardingForm),
      });
      if (response.ok) {
        setShowOnboarding(false);
        fetchEmployees();
        setOnboardingForm({ 
          username: '', 
          email: '', 
          password: '', 
          role: 'employee', 
          base_salary: '0',
          esi_enabled: false,
          pf_enabled: false,
          joining_date: new Date().toISOString().split('T')[0]
        });
      }
    } catch (err) {
      console.error('Onboarding failed', err);
    } finally {
      setLoading(false);
    }
  };
  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`/api/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profileForm),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Update failed');

      setUser(data);
      setShowProfile(false);
      setStatus('success');
      setTimeout(() => setStatus('idle'), 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-neutral-50 dark:bg-neutral-950 flex items-center justify-center p-4 font-sans transition-colors duration-300">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-white dark:bg-neutral-900 rounded-3xl shadow-sm border border-neutral-200 dark:border-neutral-800 p-8"
        >
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 rounded-2xl flex items-center justify-center mb-4">
              <MapPin className="text-emerald-600 dark:text-emerald-400 w-8 h-8" />
            </div>
            <h1 className="text-2xl font-semibold text-neutral-900 dark:text-white">GeoAttend</h1>
            <p className="text-neutral-500 dark:text-neutral-400 text-sm mt-1">
              {isRegistering ? 'Create your account' : 'Sign in to track attendance'}
            </p>
          </div>

          <form onSubmit={handleAuth} className="space-y-4">
            {isRegistering ? (
              <>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1 ml-1">Username</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-600 w-5 h-5" />
                    <input
                      type="text"
                      required
                      value={authForm.username}
                      onChange={(e) => setAuthForm({ ...authForm, username: e.target.value })}
                      placeholder="Choose a username"
                      className="w-full pl-10 pr-4 py-3 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 dark:text-white transition-all"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1 ml-1">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-600 w-5 h-5" />
                    <input
                      type="email"
                      required
                      value={authForm.email}
                      onChange={(e) => setAuthForm({ ...authForm, email: e.target.value })}
                      placeholder="Enter your email"
                      className="w-full pl-10 pr-4 py-3 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 dark:text-white transition-all"
                    />
                  </div>
                </div>
              </>
            ) : (
              <div>
                <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1 ml-1">Username or Email</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-600 w-5 h-5" />
                  <input
                    type="text"
                    required
                    value={authForm.identifier}
                    onChange={(e) => setAuthForm({ ...authForm, identifier: e.target.value })}
                    placeholder="Username or email"
                    className="w-full pl-10 pr-4 py-3 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 dark:text-white transition-all"
                  />
                </div>
              </div>
            )}
            <div>
              <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1 ml-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-600 w-5 h-5" />
                <input
                  type="password"
                  required
                  value={authForm.password}
                  onChange={(e) => setAuthForm({ ...authForm, password: e.target.value })}
                  placeholder="Enter password"
                  className="w-full pl-10 pr-4 py-3 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 dark:text-white transition-all"
                />
              </div>
            </div>

            {error && (
              <div className={`p-3 rounded-xl text-sm flex items-center gap-2 ${status === 'success' ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400' : 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400'}`}>
                {status === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-neutral-900 dark:bg-white dark:text-neutral-900 text-white py-3 rounded-xl font-medium hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors active:scale-[0.98] flex items-center justify-center gap-2"
            >
              {loading && <Loader2 className="w-5 h-5 animate-spin" />}
              {isRegistering ? 'Create Account' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button 
              onClick={() => { setIsRegistering(!isRegistering); setError(null); setStatus('idle'); }}
              className="text-sm text-emerald-600 font-medium hover:underline"
            >
              {isRegistering ? 'Already have an account? Sign in' : 'Don\'t have an account? Register'}
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-950 font-sans pb-12 transition-colors duration-300">
      {/* Header */}
      <header className="bg-white dark:bg-neutral-900 border-b border-neutral-200 dark:border-neutral-800 sticky top-0 z-10 transition-colors duration-300">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-emerald-600 dark:bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <MapPin className="text-white w-6 h-6" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-lg font-bold text-neutral-900 dark:text-white leading-tight">GeoAttend</h1>
              <p className="text-[10px] text-neutral-400 dark:text-neutral-500 font-medium uppercase tracking-widest">HR Suite</p>
            </div>
          </div>

            <div className="flex items-center gap-2 sm:gap-4">
              <div className="hidden lg:flex items-center bg-neutral-100 dark:bg-neutral-800 rounded-xl p-1">
                <button 
                  onClick={() => setActiveTab('attendance')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${activeTab === 'attendance' ? 'bg-white dark:bg-neutral-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300'}`}
                >
                  Attendance
                </button>
                <button 
                  onClick={() => setActiveTab('leaves')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${activeTab === 'leaves' ? 'bg-white dark:bg-neutral-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300'}`}
                >
                  Leaves
                </button>
                <button 
                  onClick={() => setActiveTab('expenses')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${activeTab === 'expenses' ? 'bg-white dark:bg-neutral-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300'}`}
                >
                  Expenses
                </button>
                <button 
                  onClick={() => setActiveTab('announcements')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${activeTab === 'announcements' ? 'bg-white dark:bg-neutral-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300'}`}
                >
                  Announcements
                </button>
                <button 
                  onClick={() => { setActiveTab('payroll'); fetchPayroll(user.id); }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${activeTab === 'payroll' ? 'bg-white dark:bg-neutral-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300'}`}
                >
                  Payroll
                </button>
                {user.role !== 'employee' && (
                  <>
                    <button 
                      onClick={() => setActiveTab('hr')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${activeTab === 'hr' ? 'bg-white dark:bg-neutral-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300'}`}
                    >
                      {user.role === 'ceo' ? 'CEO' : 'HR'}
                    </button>
                    <button 
                      onClick={() => setActiveTab('config')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${activeTab === 'config' ? 'bg-white dark:bg-neutral-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300'}`}
                    >
                      Config
                    </button>
                  </>
                )}
              </div>

              <div className="lg:hidden flex items-center gap-1">
                <button 
                  onClick={() => setActiveTab('attendance')}
                  className={`p-2 rounded-lg transition-all ${activeTab === 'attendance' ? 'text-emerald-600 dark:text-emerald-400' : 'text-neutral-400'}`}
                >
                  <Clock className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => setActiveTab('leaves')}
                  className={`p-2 rounded-lg transition-all ${activeTab === 'leaves' ? 'text-emerald-600 dark:text-emerald-400' : 'text-neutral-400'}`}
                >
                  <Calendar className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => setActiveTab('announcements')}
                  className={`p-2 rounded-lg transition-all ${activeTab === 'announcements' ? 'text-emerald-600 dark:text-emerald-400' : 'text-neutral-400'}`}
                >
                  <Megaphone className="w-5 h-5" />
                </button>
                {user.role !== 'employee' && (
                  <button 
                    onClick={() => setActiveTab('hr')}
                    className={`p-2 rounded-lg transition-all ${activeTab === 'hr' ? 'text-emerald-600 dark:text-emerald-400' : 'text-neutral-400'}`}
                  >
                    <Users className="w-5 h-5" />
                  </button>
                )}
              </div>

            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 text-neutral-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
              title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-neutral-900 dark:text-white cursor-pointer hover:underline" onClick={() => setShowProfile(true)}>
                {user.username || 'User'}
              </p>
              <p className="text-[10px] text-neutral-500 dark:text-neutral-400 uppercase font-bold tracking-tighter">{user.role}</p>
            </div>
            {user.role === 'ceo' && (
              <button 
                onClick={() => setShowSettings(true)}
                className="p-2 text-neutral-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
              >
                <Settings className="w-5 h-5" />
              </button>
            )}
            <button 
              onClick={() => setUser(null)}
              className="p-2 text-neutral-400 hover:text-red-500 transition-colors"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {activeTab === 'attendance' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Action Card */}
            <div className="md:col-span-1 space-y-6">
              <div className="bg-white dark:bg-neutral-900 rounded-3xl p-6 shadow-sm border border-neutral-200 dark:border-neutral-800 transition-colors duration-300">
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 dark:text-white">
                  <Clock className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  Time Tracker
                </h2>
                
                <div className="mb-6 aspect-square rounded-2xl overflow-hidden border border-neutral-100 dark:border-neutral-800 relative z-0">
                  {!isNaN(parseFloat(settings.office_lat)) && !isNaN(parseFloat(settings.office_lng)) ? (
                    <MapContainer 
                      center={[parseFloat(settings.office_lat), parseFloat(settings.office_lng)]} 
                      zoom={16} 
                      scrollWheelZoom={false}
                      style={{ height: '100%', width: '100%' }}
                    >
                      <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                      />
                      <MapRecenter center={location ? [location.lat, location.lng] : [parseFloat(settings.office_lat), parseFloat(settings.office_lng)]} />
                      
                      {locations.length > 0 ? (
                        locations.map(loc => (
                          <React.Fragment key={loc.id}>
                            <Marker 
                              position={[loc.latitude, loc.longitude]}
                              icon={officeIcon}
                            >
                              <Popup>{loc.name}</Popup>
                            </Marker>
                            <Circle 
                              center={[loc.latitude, loc.longitude]}
                              radius={loc.radius}
                              pathOptions={{ 
                                color: locationVerified && calculateDistance(location?.lat || 0, location?.lng || 0, loc.latitude, loc.longitude) <= loc.radius ? '#10b981' : '#6b7280', 
                                fillColor: locationVerified && calculateDistance(location?.lat || 0, location?.lng || 0, loc.latitude, loc.longitude) <= loc.radius ? '#10b981' : '#6b7280', 
                                fillOpacity: 0.1 
                              }}
                            />
                          </React.Fragment>
                        ))
                      ) : (
                        <>
                          <Marker 
                            position={[parseFloat(settings.office_lat), parseFloat(settings.office_lng)]}
                            icon={officeIcon}
                          >
                            <Popup>Office Location</Popup>
                          </Marker>
                          <Circle 
                            center={[parseFloat(settings.office_lat), parseFloat(settings.office_lng)]}
                            radius={parseFloat(settings.allowed_radius)}
                            pathOptions={{ color: '#10b981', fillColor: '#10b981', fillOpacity: 0.1 }}
                          />
                        </>
                      )}

                      {location && (
                        <Marker position={[location.lat, location.lng]}>
                          <Popup>Your Location</Popup>
                        </Marker>
                      )}
                    </MapContainer>
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-800 text-neutral-400">
                      <Loader2 className="w-6 h-6 animate-spin" />
                    </div>
                  )}
                  <div className="absolute bottom-2 right-2 z-10">
                    <button 
                      onClick={async () => {
                        try {
                          const loc = await getLocation();
                          setLocation(loc);
                        } catch (e) {
                          setError("Could not get location. Please enable GPS.");
                        }
                      }}
                      className="p-2 bg-white dark:bg-neutral-800 rounded-lg shadow-md text-emerald-600"
                      title="Refresh My Location"
                    >
                      <MapIcon className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  <button
                    disabled={loading}
                    onClick={verifyLocation}
                    className={`w-full flex items-center justify-center gap-2 py-3 rounded-2xl font-semibold transition-all active:scale-[0.98] border-2 ${
                      locationVerified === true 
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-700 dark:bg-emerald-900/20 dark:border-emerald-500/50 dark:text-emerald-400' 
                        : locationVerified === false
                        ? 'bg-red-50 border-red-500 text-red-700 dark:bg-red-900/20 dark:border-red-500/50 dark:text-red-400'
                        : 'bg-neutral-50 border-neutral-200 text-neutral-600 dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-400'
                    }`}
                  >
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <MapPin className="w-5 h-5" />}
                    {locationVerified === true ? 'Location Verified' : locationVerified === false ? 'Location Denied' : 'Verify My Location'}
                  </button>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="col-span-2 p-3 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-100 dark:border-neutral-700 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Navigation className="w-4 h-4 text-neutral-400" />
                        <span className="text-xs text-neutral-500 dark:text-neutral-400">Distance to Office</span>
                      </div>
                      <span className={`text-xs font-bold ${locationVerified ? 'text-emerald-600' : 'text-red-600'}`}>
                        {distanceFromOffice !== null ? `${Math.round(distanceFromOffice)}m` : '---'}
                      </span>
                    </div>
                    <button
                      disabled={loading || locationVerified !== true}
                      onClick={() => handleAttendance('check-in')}
                      className="flex items-center justify-center gap-2 bg-emerald-600 dark:bg-emerald-500 text-white py-4 rounded-2xl font-semibold hover:bg-emerald-700 dark:hover:bg-emerald-600 transition-all disabled:opacity-50 disabled:grayscale active:scale-[0.98]"
                    >
                      {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                      Check In
                    </button>
                    <button
                      disabled={loading || locationVerified !== true}
                      onClick={() => handleAttendance('check-out')}
                      className="flex items-center justify-center gap-2 bg-neutral-900 dark:bg-neutral-800 text-white py-4 rounded-2xl font-semibold hover:bg-neutral-800 dark:hover:bg-neutral-700 transition-all disabled:opacity-50 disabled:grayscale active:scale-[0.98]"
                    >
                      {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <LogOut className="w-5 h-5" />}
                      Check Out
                    </button>
                  </div>
                </div>

                <AnimatePresence>
                  {status === 'success' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 p-3 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 rounded-xl text-sm flex items-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      Attendance recorded successfully!
                    </motion.div>
                  )}
                  {error && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 rounded-xl text-sm flex items-center gap-2"
                    >
                      <AlertCircle className="w-4 h-4" />
                      {error}
                    </motion.div>
                  )}
                </AnimatePresence>

                {location && (
                  <div className="mt-6 pt-6 border-t border-neutral-100 dark:border-neutral-800">
                    <p className="text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-2">Current Location</p>
                    <div className="flex items-center gap-3 text-sm text-neutral-600 dark:text-neutral-400">
                      <div className="w-8 h-8 bg-neutral-100 dark:bg-neutral-800 rounded-lg flex items-center justify-center">
                        <MapPin className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="font-mono">{location.lat.toFixed(4)}, {location.lng.toFixed(4)}</p>
                      </div>
                    </div>
                  </div>
                )}

                <div className="mt-4 pt-4 border-t border-neutral-100 dark:border-neutral-800">
                  <p className="text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-2">Office Zone</p>
                  <div className="flex items-center gap-3 text-xs text-neutral-500 dark:text-neutral-400">
                    <div className="w-6 h-6 bg-emerald-50 dark:bg-emerald-900/30 rounded-full flex items-center justify-center">
                      <div className="w-2 h-2 bg-emerald-500 dark:bg-emerald-400 rounded-full animate-pulse" />
                    </div>
                    <p>Radius: {settings.allowed_radius}m from Office</p>
                  </div>
                </div>
              </div>
            </div>

            {/* History List */}
            <div className="md:col-span-2">
              <div className="bg-white dark:bg-neutral-900 rounded-3xl shadow-sm border border-neutral-200 dark:border-neutral-800 overflow-hidden transition-colors duration-300">
                <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                  <h2 className="text-lg font-semibold flex items-center gap-2 dark:text-white">
                    <History className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    Recent Activity
                  </h2>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => setShowMap(!showMap)}
                      className={`text-xs font-medium px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors ${showMap ? 'bg-emerald-600 text-white' : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-500 dark:text-neutral-400 hover:bg-neutral-200'}`}
                    >
                      <MapIcon className="w-3 h-3" />
                      {showMap ? 'Hide Map' : 'Show Map'}
                    </button>
                    <button 
                      onClick={exportAttendance}
                      className="text-xs font-medium bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 px-3 py-1.5 rounded-lg flex items-center gap-1 hover:bg-emerald-100 transition-colors"
                    >
                      <Download className="w-3 h-3" />
                      Export
                    </button>
                    <span className="text-xs font-medium bg-neutral-100 dark:bg-neutral-800 text-neutral-500 dark:text-neutral-400 px-2 py-1 rounded-full">
                      {records.length} Records
                    </span>
                  </div>
                </div>

                <div className="divide-y divide-neutral-50 dark:divide-neutral-800">
                  {showMap && (
                    <div className="p-4 bg-neutral-50 dark:bg-neutral-800/50 border-b border-neutral-100 dark:border-neutral-800">
                      <div className="aspect-video bg-neutral-200 dark:bg-neutral-700 rounded-2xl relative overflow-hidden border border-neutral-200 dark:border-neutral-700 z-0">
                        <MapContainer 
                          center={[parseFloat(settings.office_lat), parseFloat(settings.office_lng)]} 
                          zoom={15} 
                          scrollWheelZoom={false}
                          style={{ height: '100%', width: '100%' }}
                        >
                          <TileLayer
                            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                          />
                          <MapRecenter center={historyMapCenter || [parseFloat(settings.office_lat), parseFloat(settings.office_lng)]} />
                          {/* Office Marker */}
                          <Marker 
                            position={[parseFloat(settings.office_lat), parseFloat(settings.office_lng)]}
                            icon={officeIcon}
                          >
                            <Popup>
                              <div className="text-xs font-semibold">Office Location</div>
                            </Popup>
                          </Marker>
                          
                          {/* Attendance Markers */}
                          {records.map((r) => (
                            <Marker 
                              key={`attendance-marker-${r.id}`} 
                              position={[r.latitude, r.longitude]}
                            >
                              <Popup>
                                <div className="text-xs">
                                  <p className="font-bold">{r.user_name}</p>
                                  <p className="capitalize">{r.type} - {r.status}</p>
                                  <p className="text-[10px] text-neutral-500">{new Date(r.timestamp).toLocaleString()}</p>
                                </div>
                              </Popup>
                            </Marker>
                          ))}

                          {/* Live Location Markers */}
                          {user.role !== 'employee' && liveLocations.map((l) => (
                            <Marker 
                              key={`live-${l.user_id}`} 
                              position={[l.latitude, l.longitude]}
                              icon={new L.Icon({
                                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
                                shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
                                iconSize: [25, 41],
                                iconAnchor: [12, 41],
                                popupAnchor: [1, -34],
                                shadowSize: [41, 41]
                              })}
                            >
                              <Popup>
                                <div className="text-xs">
                                  <p className="font-bold text-blue-600">LIVE: {l.username}</p>
                                  <p className="text-[10px] text-neutral-500">Updated: {new Date(l.last_updated).toLocaleTimeString()}</p>
                                </div>
                              </Popup>
                            </Marker>
                          ))}
                        </MapContainer>
                        <div className="absolute bottom-4 right-4 z-10">
                          <button 
                            onClick={() => {
                              setHistoryMapCenter([parseFloat(settings.office_lat), parseFloat(settings.office_lng)]);
                              // Reset after a short delay so it can be triggered again if needed
                              setTimeout(() => setHistoryMapCenter(null), 100);
                            }}
                            className="p-2 bg-white dark:bg-neutral-800 rounded-lg shadow-md text-emerald-600 hover:bg-neutral-50 transition-colors"
                            title="Center on Office"
                          >
                            <MapPin className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                  {records.length === 0 ? (
                    <div className="p-12 text-center">
                      <div className="w-12 h-12 bg-neutral-50 dark:bg-neutral-800/50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <History className="text-neutral-300 dark:text-neutral-700 w-6 h-6" />
                      </div>
                      <p className="text-neutral-500 dark:text-neutral-400">No attendance records yet.</p>
                    </div>
                  ) : (
                    records.map((record) => (
                      <div key={`attendance-list-${record.id}`} className="p-4 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                            record.type === 'check-in' 
                              ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' 
                              : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'
                          }`}>
                            {record.type === 'check-in' ? <CheckCircle2 className="w-5 h-5" /> : <LogOut className="w-5 h-5" />}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-neutral-900 dark:text-white capitalize">
                              {record.user_name || 'Unknown User'}
                            </p>
                            <div className="flex items-center gap-2">
                              <p className="text-xs text-neutral-500 dark:text-neutral-400 flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {new Date(record.timestamp).toLocaleString()}
                              </p>
                              {record.status === 'late' && (
                                <span className="text-[10px] bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 px-1.5 py-0.5 rounded font-bold uppercase">Late</span>
                              )}
                              {record.status === 'regularized' && (
                                <span className="text-[10px] bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 px-1.5 py-0.5 rounded font-bold uppercase">Regularized</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right flex items-center gap-4">
                          {record.status === 'late' && (
                            <button 
                              onClick={() => {
                                const reason = prompt('Reason for regularization:');
                                if (reason) handleRegularize(record.id, reason);
                              }}
                              className="text-[10px] text-emerald-600 hover:underline font-bold uppercase tracking-wider"
                            >
                              Regularize
                            </button>
                          )}
                          <div>
                            <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded-md ${
                              record.type === 'check-in' 
                                ? 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300' 
                                : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300'
                            }`}>
                              {record.type}
                            </span>
                            <p className="text-[10px] font-mono text-neutral-400 dark:text-neutral-500 mt-1">
                              {record.latitude.toFixed(3)}, {record.longitude.toFixed(3)}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'hr' && user.role !== 'employee' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-neutral-900 rounded-3xl shadow-sm border border-neutral-200 dark:border-neutral-800 overflow-hidden">
              <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <h2 className="text-lg font-semibold flex items-center gap-2 dark:text-white">
                  <Users className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  Employee Onboarding & Management
                </h2>
                <button 
                  onClick={() => setShowOnboarding(true)}
                  className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors flex items-center gap-2"
                >
                  <Users className="w-4 h-4" />
                  Onboard Employee
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-neutral-50 dark:bg-neutral-800/50 text-neutral-500 dark:text-neutral-400 text-xs uppercase tracking-wider">
                    <tr>
                      <th className="px-6 py-4 font-semibold">Employee</th>
                      <th className="px-6 py-4 font-semibold">Role</th>
                      <th className="px-6 py-4 font-semibold">Base Salary</th>
                      <th className="px-6 py-4 font-semibold">Benefits</th>
                      <th className="px-6 py-4 font-semibold">Joined</th>
                      <th className="px-6 py-4 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                    {employees.map(emp => (
                      <tr key={`employee-row-${emp.id}`} className="hover:bg-neutral-50 dark:hover:bg-neutral-800/30 transition-colors">
                        <td className="px-6 py-4">
                          <p className="text-sm font-semibold dark:text-white">{emp.username}</p>
                          <p className="text-xs text-neutral-500">{emp.email}</p>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-[10px] font-bold uppercase tracking-wider bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 px-2 py-1 rounded">
                            {emp.role}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm dark:text-white font-mono">
                          ₹{emp.base_salary.toLocaleString('en-IN')}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex gap-1">
                            {emp.esi_enabled === 1 && <span className="text-[8px] bg-blue-50 dark:bg-blue-900/30 text-blue-600 px-1.5 py-0.5 rounded font-bold">ESI</span>}
                            {emp.pf_enabled === 1 && <span className="text-[8px] bg-purple-50 dark:bg-purple-900/30 text-purple-600 px-1.5 py-0.5 rounded font-bold">PF</span>}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-xs text-neutral-500">
                          {new Date(emp.joining_date).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button 
                              onClick={() => {
                                setSelectedEmployeeHistory(emp);
                                fetchRecords(emp.id, false);
                              }}
                              className="p-2 text-neutral-400 hover:text-emerald-600 transition-colors"
                              title="View Attendance History"
                            >
                              <History className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => handleDeleteEmployee(emp.id)}
                              disabled={emp.id === user?.id}
                              className="p-2 text-neutral-400 hover:text-red-500 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                              title="Delete Employee"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'leaves' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold dark:text-white">Leave Management</h2>
              <button 
                onClick={() => setShowLeaveModal(true)}
                className="bg-emerald-600 text-white px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-emerald-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Apply Leave
              </button>
            </div>
            <div className="bg-white dark:bg-neutral-900 rounded-3xl shadow-sm border border-neutral-200 dark:border-neutral-800 overflow-hidden">
              <div className="p-6 border-b border-neutral-100 dark:border-neutral-800">
                <h3 className="font-semibold dark:text-white">Leave Requests</h3>
              </div>
              <div className="divide-y divide-neutral-100 dark:divide-neutral-800">
                {leaves.length === 0 ? (
                  <div className="p-12 text-center text-neutral-500">No leave requests found.</div>
                ) : (
                  leaves.map((l) => (
                    <div key={`leave-${l.id}`} className="p-6 flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                          l.type === 'sick' ? 'bg-red-50 text-red-600' : 
                          l.type === 'casual' ? 'bg-blue-50 text-blue-600' : 
                          'bg-emerald-50 text-emerald-600'
                        }`}>
                          <Calendar className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-semibold dark:text-white capitalize">{l.type} Leave {user.role !== 'employee' && <span className="text-neutral-400 font-normal">by {l.username}</span>}</p>
                          <p className="text-xs text-neutral-500">{new Date(l.start_date).toLocaleDateString()} - {new Date(l.end_date).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          l.status === 'approved' ? 'bg-emerald-50 text-emerald-600' : 
                          l.status === 'rejected' ? 'bg-red-50 text-red-600' : 
                          'bg-amber-50 text-amber-600'
                        }`}>
                          {l.status}
                        </span>
                        {user.role !== 'employee' && l.status === 'pending' && (
                          <div className="flex gap-2">
                            <button 
                              onClick={async () => {
                                await fetch(`/api/leaves/${l.id}`, {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ status: 'approved' })
                                });
                                fetchLeaves();
                              }}
                              className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={async () => {
                                await fetch(`/api/leaves/${l.id}`, {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ status: 'rejected' })
                                });
                                fetchLeaves();
                              }}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'announcements' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold dark:text-white">Announcements</h2>
              {user.role !== 'employee' && (
                <button 
                  onClick={() => setShowAnnouncementModal(true)}
                  className="bg-emerald-600 text-white px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-emerald-700 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  New Post
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 gap-6">
              {announcements.length === 0 ? (
                <div className="bg-white dark:bg-neutral-900 p-12 rounded-3xl text-center text-neutral-500 border border-neutral-200 dark:border-neutral-800">No announcements yet.</div>
              ) : (
                announcements.map((a) => (
                  <motion.div 
                    key={`announcement-${a.id}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white dark:bg-neutral-900 p-6 rounded-3xl shadow-sm border border-neutral-200 dark:border-neutral-800"
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl flex items-center justify-center">
                        <Megaphone className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                      </div>
                      <div>
                        <h3 className="font-bold dark:text-white">{a.title}</h3>
                        <p className="text-xs text-neutral-500">Posted by {a.author_name} • {new Date(a.created_at).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <p className="text-neutral-600 dark:text-neutral-400 text-sm leading-relaxed">{a.content}</p>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'config' && user?.role !== 'employee' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Locations Management */}
              <div className="bg-white dark:bg-neutral-900 rounded-3xl p-8 border border-neutral-100 dark:border-neutral-800 shadow-sm">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-2xl font-bold dark:text-white">Office Locations</h2>
                    <p className="text-neutral-500 dark:text-neutral-400 text-sm">Manage geofenced office locations</p>
                  </div>
                  <div className="flex items-center gap-3">
                    {locations.length > 0 && (
                      <button
                        onClick={async () => {
                          if (confirm('Are you sure you want to delete ALL locations?')) {
                            try {
                              const response = await fetch('/api/locations/all', {
                                method: 'DELETE',
                                headers: { 'x-user-role': user?.role || '' }
                              });
                              if (response.ok) {
                                fetchLocations();
                              } else {
                                const err = await response.json();
                                alert(`Failed to clear locations: ${err.error}`);
                              }
                            } catch (err) {
                              console.error('Failed to clear locations', err);
                            }
                          }
                        }}
                        className="px-4 py-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl text-sm font-medium transition-colors flex items-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        Clear All
                      </button>
                    )}
                    <MapPin className="w-8 h-8 text-emerald-600 dark:text-emerald-400 opacity-20" />
                  </div>
                </div>
                <div className="space-y-4">
                  {locations.map(loc => (
                    <div key={loc.id} className="p-4 bg-neutral-50 dark:bg-neutral-800 rounded-2xl border border-neutral-100 dark:border-neutral-700">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold dark:text-white">{loc.name}</h4>
                          <p className="text-xs text-neutral-500 dark:text-neutral-400">
                            {loc.latitude}, {loc.longitude} (Radius: {loc.radius}m)
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleDeleteLocation(loc.id)}
                            className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                            title="Delete Location"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <span className="px-2 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold uppercase tracking-wider rounded-lg">
                            Active
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Shifts Management */}
              <div className="bg-white dark:bg-neutral-900 rounded-3xl p-8 border border-neutral-100 dark:border-neutral-800 shadow-sm">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-2xl font-bold dark:text-white">Work Shifts</h2>
                    <p className="text-neutral-500 dark:text-neutral-400 text-sm">Define employee working hours</p>
                  </div>
                  <Clock className="w-8 h-8 text-emerald-600 dark:text-emerald-400 opacity-20" />
                </div>
                <div className="space-y-4">
                  {shifts.map(s => (
                    <div key={s.id} className="p-4 bg-neutral-50 dark:bg-neutral-800 rounded-2xl border border-neutral-100 dark:border-neutral-700">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold dark:text-white">{s.name}</h4>
                          <p className="text-xs text-neutral-500 dark:text-neutral-400">
                            {s.start_time} - {s.end_time}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[10px] font-bold uppercase tracking-wider rounded-lg">
                            Standard
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'expenses' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold dark:text-white">Expense Claims</h2>
              <button 
                onClick={() => setShowExpenseModal(true)}
                className="bg-emerald-600 text-white px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-emerald-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                New Claim
              </button>
            </div>
            <div className="bg-white dark:bg-neutral-900 rounded-3xl shadow-sm border border-neutral-200 dark:border-neutral-800 overflow-hidden">
              <div className="p-6 border-b border-neutral-100 dark:border-neutral-800">
                <h3 className="font-semibold dark:text-white">Recent Claims</h3>
              </div>
              <div className="divide-y divide-neutral-100 dark:divide-neutral-800">
                {expenses.length === 0 ? (
                  <div className="p-12 text-center text-neutral-500">No expense claims found.</div>
                ) : (
                  expenses.map((e) => (
                    <div key={`expense-${e.id}`} className="p-6 flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-neutral-100 dark:bg-neutral-800 rounded-xl flex items-center justify-center">
                          <Receipt className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
                        </div>
                        <div>
                          <p className="font-semibold dark:text-white">₹{e.amount.toLocaleString('en-IN')} - {e.category} {user.role !== 'employee' && <span className="text-neutral-400 font-normal">by {e.username}</span>}</p>
                          <p className="text-xs text-neutral-500">{e.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          e.status === 'approved' ? 'bg-emerald-50 text-emerald-600' : 
                          e.status === 'rejected' ? 'bg-red-50 text-red-600' : 
                          'bg-amber-50 text-amber-600'
                        }`}>
                          {e.status}
                        </span>
                        {user.role !== 'employee' && e.status === 'pending' && (
                          <div className="flex gap-2">
                            <button 
                              onClick={async () => {
                                await fetch(`/api/expenses/${e.id}`, {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ status: 'approved' })
                                });
                                fetchExpenses();
                              }}
                              className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={async () => {
                                await fetch(`/api/expenses/${e.id}`, {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ status: 'rejected' })
                                });
                                fetchExpenses();
                              }}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'payroll' && payroll && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white dark:bg-neutral-900 rounded-3xl shadow-xl border border-neutral-200 dark:border-neutral-800 overflow-hidden">
              <div className="p-8 bg-neutral-900 dark:bg-neutral-800 text-white">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h2 className="text-2xl font-bold">Salary Slip</h2>
                    <p className="text-neutral-400 text-sm">Month: {new Date().toLocaleString('default', { month: 'long', year: 'numeric' })}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-emerald-400 font-bold text-xl">GeoAttend</p>
                    <p className="text-neutral-400 text-[10px] uppercase tracking-widest">HR & Payroll Systems</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-8">
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-neutral-500 mb-1">Employee Name</p>
                    <p className="font-semibold">{user.username}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] uppercase tracking-widest text-neutral-500 mb-1">Designation</p>
                    <p className="font-semibold uppercase">{user.role}</p>
                  </div>
                </div>
              </div>

              <div className="p-8 space-y-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-neutral-500">Basic Salary</span>
                    <span className="font-mono dark:text-white">₹{payroll.base.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-neutral-500">Provident Fund (PF)</span>
                    <span className="font-mono text-red-500">-₹{payroll.pf.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-neutral-500">ESI Contribution</span>
                    <span className="font-mono text-red-500">-₹{payroll.esi.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-neutral-500">Penalties / Deductions</span>
                    <span className="font-mono text-red-500">-₹{payroll.penalties.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <div className="pt-6 border-t border-neutral-100 dark:border-neutral-800">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold dark:text-white">Net Salary</span>
                    <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 font-mono">₹{payroll.net.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <button className="w-full mt-8 flex items-center justify-center gap-2 bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 py-3 rounded-xl text-sm font-semibold hover:bg-neutral-200 transition-colors">
                  <Download className="w-4 h-4" />
                  Download PDF Statement
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Settings Modal */}
      <AnimatePresence>
        {showProfile && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowProfile(false)}
              className="absolute inset-0 bg-neutral-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-white dark:bg-neutral-900 rounded-3xl shadow-xl overflow-hidden border border-neutral-200 dark:border-neutral-800"
            >
              <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <h3 className="text-lg font-semibold flex items-center gap-2 dark:text-white">
                  <User className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  User Profile
                </h3>
                <button 
                  onClick={() => setShowProfile(false)}
                  className="p-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleProfileUpdate} className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1 ml-1">Username</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-600 w-5 h-5" />
                    <input
                      type="text"
                      required
                      value={profileForm.username}
                      onChange={(e) => setProfileForm({ ...profileForm, username: e.target.value })}
                      className="w-full pl-10 pr-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1 ml-1">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-600 w-5 h-5" />
                    <input
                      type="email"
                      required
                      value={profileForm.email}
                      onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                      className="w-full pl-10 pr-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1 ml-1">New Password (optional)</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-600 w-5 h-5" />
                    <input
                      type="password"
                      value={profileForm.password}
                      onChange={(e) => setProfileForm({ ...profileForm, password: e.target.value })}
                      placeholder="Leave blank to keep current"
                      className="w-full pl-10 pr-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    />
                  </div>
                </div>
                <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800">
                  <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1 ml-1">Current Password (required to save)</label>
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-600 w-5 h-5" />
                    <input
                      type="password"
                      required
                      value={profileForm.currentPassword}
                      onChange={(e) => setProfileForm({ ...profileForm, currentPassword: e.target.value })}
                      className="w-full pl-10 pr-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    />
                  </div>
                </div>

                {error && (
                  <div className="p-3 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 rounded-xl text-sm flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    {error}
                  </div>
                )}

                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full flex items-center justify-center gap-2 bg-emerald-600 text-white py-3 rounded-xl font-medium hover:bg-emerald-700 transition-all disabled:opacity-50"
                  >
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    Update Profile
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}

        {showSettings && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettings(false)}
              className="absolute inset-0 bg-neutral-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-white dark:bg-neutral-900 rounded-3xl shadow-xl overflow-hidden border border-neutral-200 dark:border-neutral-800"
            >
              <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <h3 className="text-lg font-semibold flex items-center gap-2 dark:text-white">
                  <Settings className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  Office Configuration
                </h3>
                <button 
                  onClick={() => setShowSettings(false)}
                  className="p-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={saveSettings} className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1">
                      Latitude
                    </label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={settings.office_lat}
                      onChange={(e) => setSettings({ ...settings, office_lat: e.target.value })}
                      className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1">
                      Longitude
                    </label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={settings.office_lng}
                      onChange={(e) => setSettings({ ...settings, office_lng: e.target.value })}
                      className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1">
                    Allowed Radius (meters)
                  </label>
                  <input
                    type="number"
                    required
                    value={settings.allowed_radius}
                    onChange={(e) => setSettings({ ...settings, allowed_radius: e.target.value })}
                    className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                  />
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full flex items-center justify-center gap-2 bg-emerald-600 text-white py-3 rounded-xl font-medium hover:bg-emerald-700 transition-all disabled:opacity-50"
                  >
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    Save Configuration
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* Onboarding Modal */}
      <AnimatePresence>
        {showOnboarding && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowOnboarding(false)}
              className="absolute inset-0 bg-neutral-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-white dark:bg-neutral-900 rounded-3xl shadow-xl overflow-hidden border border-neutral-200 dark:border-neutral-800"
            >
              <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <h3 className="text-lg font-semibold flex items-center gap-2 dark:text-white">
                  <Users className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  Onboard New Employee
                </h3>
                <button 
                  onClick={() => setShowOnboarding(false)}
                  className="p-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleOnboarding} className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1">Username</label>
                    <input
                      type="text"
                      required
                      value={onboardingForm.username}
                      onChange={(e) => setOnboardingForm({ ...onboardingForm, username: e.target.value })}
                      className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1">Role</label>
                    <select
                      value={onboardingForm.role}
                      onChange={(e) => setOnboardingForm({ ...onboardingForm, role: e.target.value })}
                      className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    >
                      <option value="employee">Employee</option>
                      <option value="hr">HR</option>
                      <option value="ceo">CEO</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1">Email</label>
                  <input
                    type="email"
                    required
                    value={onboardingForm.email}
                    onChange={(e) => setOnboardingForm({ ...onboardingForm, email: e.target.value })}
                    className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1">Password</label>
                  <input
                    type="password"
                    required
                    value={onboardingForm.password}
                    onChange={(e) => setOnboardingForm({ ...onboardingForm, password: e.target.value })}
                    className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1">Base Salary (₹)</label>
                    <input
                      type="number"
                      required
                      value={onboardingForm.base_salary}
                      onChange={(e) => setOnboardingForm({ ...onboardingForm, base_salary: e.target.value })}
                      className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1">Shift</label>
                    <select
                      value={onboardingForm.shift_id}
                      onChange={(e) => setOnboardingForm({ ...onboardingForm, shift_id: e.target.value })}
                      className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    >
                      {shifts.map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.start_time}-{s.end_time})</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 dark:text-neutral-500 uppercase tracking-wider mb-1">Joining Date</label>
                    <input
                      type="date"
                      required
                      value={onboardingForm.joining_date}
                      onChange={(e) => setOnboardingForm({ ...onboardingForm, joining_date: e.target.value })}
                      className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                    />
                  </div>
                </div>

                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <input 
                      type="checkbox" 
                      checked={onboardingForm.esi_enabled}
                      onChange={(e) => setOnboardingForm({ ...onboardingForm, esi_enabled: e.target.checked })}
                      className="w-4 h-4 rounded border-neutral-300 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span className="text-sm text-neutral-600 dark:text-neutral-400 group-hover:text-emerald-600 transition-colors">ESI Benefit</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <input 
                      type="checkbox" 
                      checked={onboardingForm.pf_enabled}
                      onChange={(e) => setOnboardingForm({ ...onboardingForm, pf_enabled: e.target.checked })}
                      className="w-4 h-4 rounded border-neutral-300 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span className="text-sm text-neutral-600 dark:text-neutral-400 group-hover:text-emerald-600 transition-colors">PF Benefit</span>
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-emerald-600 text-white py-3 rounded-xl font-medium hover:bg-emerald-700 transition-colors active:scale-[0.98] flex items-center justify-center gap-2"
                >
                  {loading && <Loader2 className="w-5 h-5 animate-spin" />}
                  Complete Onboarding
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Employee History Modal */}
      <AnimatePresence>
        {selectedEmployeeHistory && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedEmployeeHistory(null)}
              className="absolute inset-0 bg-neutral-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-white dark:bg-neutral-900 rounded-3xl shadow-xl overflow-hidden border border-neutral-200 dark:border-neutral-800 flex flex-col max-h-[80vh]"
            >
              <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold flex items-center gap-2 dark:text-white">
                    <History className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    Attendance History
                  </h3>
                  <p className="text-xs text-neutral-500 mt-1">{selectedEmployeeHistory.username} ({selectedEmployeeHistory.email})</p>
                </div>
                <button 
                  onClick={() => setSelectedEmployeeHistory(null)}
                  className="p-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="overflow-y-auto flex-1">
                <div className="divide-y divide-neutral-50 dark:divide-neutral-800">
                  {employeeHistoryRecords.length === 0 ? (
                    <div className="p-12 text-center">
                      <div className="w-12 h-12 bg-neutral-50 dark:bg-neutral-800/50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <History className="text-neutral-300 dark:text-neutral-700 w-6 h-6" />
                      </div>
                      <p className="text-neutral-500 dark:text-neutral-400">No attendance records found for this employee.</p>
                    </div>
                  ) : (
                    employeeHistoryRecords.map((record) => (
                      <div key={`emp-history-${record.id}`} className="p-4 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                            record.type === 'check-in' 
                              ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' 
                              : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'
                          }`}>
                            {record.type === 'check-in' ? <CheckCircle2 className="w-5 h-5" /> : <LogOut className="w-5 h-5" />}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-neutral-900 dark:text-white capitalize">
                              {record.type}
                            </p>
                            <div className="flex items-center gap-2">
                              <p className="text-xs text-neutral-500 dark:text-neutral-400 flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {new Date(record.timestamp).toLocaleString()}
                              </p>
                              {record.status === 'late' && (
                                <span className="text-[10px] bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 px-1.5 py-0.5 rounded font-bold uppercase">Late</span>
                              )}
                              {record.status === 'regularized' && (
                                <span className="text-[10px] bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 px-1.5 py-0.5 rounded font-bold uppercase">Regularized</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded-md ${
                            record.type === 'check-in' 
                              ? 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300' 
                              : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300'
                          }`}>
                            {record.status}
                          </span>
                          <p className="text-[10px] font-mono text-neutral-400 dark:text-neutral-500 mt-1">
                            {record.latitude.toFixed(3)}, {record.longitude.toFixed(3)}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {showLeaveModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowLeaveModal(false)} className="absolute inset-0 bg-neutral-900/40 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-md bg-white dark:bg-neutral-900 rounded-3xl shadow-xl overflow-hidden border border-neutral-200 dark:border-neutral-800">
              <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <h3 className="text-lg font-semibold flex items-center gap-2 dark:text-white"><Calendar className="w-5 h-5 text-emerald-600" /> Apply for Leave</h3>
                <button onClick={() => setShowLeaveModal(false)} className="p-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"><X className="w-5 h-5" /></button>
              </div>
              <form onSubmit={async (e) => {
                e.preventDefault();
                setLoading(true);
                await fetch('/api/leaves', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ ...leaveForm, userId: user.id })
                });
                setLoading(false);
                setShowLeaveModal(false);
                fetchLeaves(user.role === 'employee' ? user.id : undefined);
              }} className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">Leave Type</label>
                  <select 
                    value={leaveForm.type}
                    onChange={(e) => setLeaveForm({ ...leaveForm, type: e.target.value as any })}
                    className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white"
                  >
                    <option value="sick">Sick Leave</option>
                    <option value="casual">Casual Leave</option>
                    <option value="earned">Earned Leave</option>
                    <option value="unpaid">Unpaid Leave</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">Start Date</label>
                    <input type="date" required value={leaveForm.start_date} onChange={(e) => setLeaveForm({ ...leaveForm, start_date: e.target.value })} className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">End Date</label>
                    <input type="date" required value={leaveForm.end_date} onChange={(e) => setLeaveForm({ ...leaveForm, end_date: e.target.value })} className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">Reason</label>
                  <textarea required value={leaveForm.reason} onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })} className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white h-24" placeholder="Briefly explain the reason..." />
                </div>
                <button type="submit" disabled={loading} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-medium hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2">
                  {loading && <Loader2 className="w-5 h-5 animate-spin" />} Submit Request
                </button>
              </form>
            </motion.div>
          </div>
        )}

        {showAnnouncementModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowAnnouncementModal(false)} className="absolute inset-0 bg-neutral-900/40 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-md bg-white dark:bg-neutral-900 rounded-3xl shadow-xl overflow-hidden border border-neutral-200 dark:border-neutral-800">
              <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <h3 className="text-lg font-semibold flex items-center gap-2 dark:text-white"><Megaphone className="w-5 h-5 text-emerald-600" /> New Announcement</h3>
                <button onClick={() => setShowAnnouncementModal(false)} className="p-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"><X className="w-5 h-5" /></button>
              </div>
              <form onSubmit={async (e) => {
                e.preventDefault();
                setLoading(true);
                await fetch('/api/announcements', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ ...announcementForm, authorId: user.id })
                });
                setLoading(false);
                setShowAnnouncementModal(false);
                fetchAnnouncements();
              }} className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">Title</label>
                  <input type="text" required value={announcementForm.title} onChange={(e) => setAnnouncementForm({ ...announcementForm, title: e.target.value })} className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white" placeholder="Announcement title..." />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">Content</label>
                  <textarea required value={announcementForm.content} onChange={(e) => setAnnouncementForm({ ...announcementForm, content: e.target.value })} className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white h-32" placeholder="Write your announcement here..." />
                </div>
                <button type="submit" disabled={loading} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-medium hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2">
                  {loading && <Loader2 className="w-5 h-5 animate-spin" />} Post Announcement
                </button>
              </form>
            </motion.div>
          </div>
        )}

        {showExpenseModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setShowExpenseModal(false)} className="absolute inset-0 bg-neutral-900/40 backdrop-blur-sm" />
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative w-full max-w-md bg-white dark:bg-neutral-900 rounded-3xl shadow-xl overflow-hidden border border-neutral-200 dark:border-neutral-800">
              <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <h3 className="text-lg font-semibold flex items-center gap-2 dark:text-white"><Receipt className="w-5 h-5 text-emerald-600" /> New Expense Claim</h3>
                <button onClick={() => setShowExpenseModal(false)} className="p-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"><X className="w-5 h-5" /></button>
              </div>
              <form onSubmit={async (e) => {
                e.preventDefault();
                setLoading(true);
                await fetch('/api/expenses', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ ...expenseForm, userId: user.id })
                });
                setLoading(false);
                setShowExpenseModal(false);
                fetchExpenses(user.role === 'employee' ? user.id : undefined);
              }} className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">Amount (₹)</label>
                    <input type="number" required value={expenseForm.amount} onChange={(e) => setExpenseForm({ ...expenseForm, amount: e.target.value })} className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white" placeholder="0.00" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">Category</label>
                    <select value={expenseForm.category} onChange={(e) => setExpenseForm({ ...expenseForm, category: e.target.value })} className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white">
                      <option value="travel">Travel</option>
                      <option value="food">Food</option>
                      <option value="supplies">Supplies</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 uppercase tracking-wider mb-1">Description</label>
                  <textarea required value={expenseForm.description} onChange={(e) => setExpenseForm({ ...expenseForm, description: e.target.value })} className="w-full px-4 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 dark:text-white h-24" placeholder="Describe the expense..." />
                </div>
                <button type="submit" disabled={loading} className="w-full bg-emerald-600 text-white py-3 rounded-xl font-medium hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2">
                  {loading && <Loader2 className="w-5 h-5 animate-spin" />} Submit Claim
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
